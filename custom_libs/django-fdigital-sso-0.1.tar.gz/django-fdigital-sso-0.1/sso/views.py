from django.http import JsonResponse
import requests
import furl
import jwt
from django.views.decorators.csrf import csrf_exempt
import os
import json
from django.shortcuts import render
from django.shortcuts import redirect

from .exceptions import CanNotRefreshToken

SS_EXT = os.getenv('SS_EXT')
BASE = os.path.dirname(os.path.abspath(__file__))

URL_BASE = os.getenv('URL_BASE')
RHSSO_URL_BASE = os.getenv('RHSSO_URL_BASE')
REDIRECT_URI = os.getenv('HOST') + '/sso/login-sso'


@csrf_exempt
def login_sso(request):
    if request.method == "POST":
        params = request.POST.get('fullUrl')
        if 'code' in params and 'state' in params:
            keycloak = get_keycloak_data()
            if '#' in params:
                params = params.split('#')[1].split('&')
            elif '/?' in params:
                params = params.split('/?')[1].split('&')
            else:
                params = params.split('?')[1].split('&')

            params_str = '{'
            for item in params:
                v = item.split('=')
                params_str = params_str + '"' + v[0] + '":"' + v[1] + '",'
            params_str = params_str[:-1] + '}'
            params = json.loads(params_str)

            url = RHSSO_URL_BASE + "/auth/realms/Citinova/protocol/openid-connect/token"
            headers = {
                'Content-Type': 'application/x-www-form-urlencoded',
            }
            payload = {
                'grant_type': 'authorization_code',
                'redirect_uri': REDIRECT_URI,
                'client_id': keycloak['resource'],
                'code': params['code'],
                'client_secret': keycloak['credentials']['secret'],
            }

            f = furl.furl('')
            f.args = payload

            response = requests.post(url, headers=headers, data=f.url[1:])
            if response.status_code == 200:
                tokens = response.json()
                token = tokens['access_token']
                token_parsed = jwt.decode(token, verify=False)
                if token:
                    request.session['token-{}'.format(SS_EXT)] = token
                    request.session['refresh_token-{}'.format(SS_EXT)] = tokens['refresh_token']
                    request.session['token_parsed-{}'.format(SS_EXT)] = json.dumps(token_parsed)
                    return JsonResponse({'result': 'success', 'url': "/"})
                return JsonResponse({'result': 'fail', 'message': 'Não foi possível obter o token!'})
            else:
                return JsonResponse({'result': 'fail', 'message': 'Request failed {}!'.format(response.status_code)})
        else:
            return JsonResponse({'result': 'fail', 'message': 'URL mal formada!'})
    else:
        print(request.get_full_path)
    return render(request, "sso/login_sso.html", )


def get_cadastro(request):
    perfil = None
    if 'token-{}'.format(SS_EXT) in request.session:
        token_parsed = request.session['token_parsed-{}'.format(SS_EXT)]
        token_parsed = json.loads(token_parsed)
        url = URL_BASE + "/pessoa/{}/base".format(token_parsed['preferred_username'])

        payload = {}
        headers = {
            'Authorization': 'Bearer {}'.format(request.session['token-{}'.format(SS_EXT)]),
        }

        response = requests.request("GET", url, headers=headers, data=payload)

        if response.status_code == 200:
            perfil = response.json()
        elif response.status_code in [401, 403]:
            print(response.status_code)
            if refresh_token(request):
                return get_cadastro(request)
            else:
                raise CanNotRefreshToken
        else:
            perfil = '{} - {}'.format(response.text, response.status_code)
    return perfil


@csrf_exempt
def refresh_token(request):
    import requests

    keycloak = get_keycloak_data()

    url = RHSSO_URL_BASE + "/auth/realms/Citinova/protocol/openid-connect/token"
    headers = {
        'Content-Type': 'application/x-www-form-urlencoded',
    }
    payload = {
        'grant_type': 'refresh_token',
        'client_id': keycloak['resource'],
        'client_secret': keycloak['credentials']['secret'],
        'refresh_token': request.session['refresh_token-{}'.format(SS_EXT)]
    }

    f = furl.furl('')
    f.args = payload

    response = requests.request("POST", url, headers=headers, data=payload)
    if response.status_code == 200:
        tokens = response.json()
        token = tokens['access_token']
        token_parsed = jwt.decode(token, verify=False)
        if token:
            request.session['token-{}'.format(SS_EXT)] = token
            request.session['refresh_token-{}'.format(SS_EXT)] = tokens['refresh_token']
            request.session['token_parsed-{}'.format(SS_EXT)] = json.dumps(token_parsed)
            print('atualizou o token')
            return True
    return False


def get_keycloak_data():
    return json.loads(os.getenv('KEYCLOAK'))


def redirect_to_login():
    import os
    from .views import get_keycloak_data
    keycloak = get_keycloak_data()
    return redirect(os.getenv('RHSSO_URL_BASE') +
                    '/auth/realms/Citinova/protocol/openid-connect/auth?response_type=code&'
                    'client_id={}&redirect_uri={}'.format(keycloak['resource'], REDIRECT_URI))
