class CanNotRefreshToken(Exception):
    def __init__(self):
        super().__init__("Unable to update token")
