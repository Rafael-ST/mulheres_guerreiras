from django.utils.functional import wraps
from django.shortcuts import redirect
import json
import os
from .views import get_keycloak_data
import time
from .views import REDIRECT_URI

SS_EXT = os.getenv('SS_EXT')
BASE = os.path.dirname(os.path.abspath(__file__))


def check_auth_sso(view):
    @wraps(view)
    def __check_auth_sso(request, *args, **kwargs):
        try:
            token_parsed = request.session['token_parsed-{}'.format(SS_EXT)]
            token_parsed = json.loads(token_parsed)
            if int(token_parsed['exp'] < int(time.time())):
                raise Exception('Token is expired!')
        except Exception:
            keycloak = get_keycloak_data()
            return redirect(os.getenv('RHSSO_URL_BASE') +
                            '/auth/realms/Citinova/protocol/openid-connect/auth?response_type=code&'
                            'client_id={}&redirect_uri={}'.format(keycloak['resource'], REDIRECT_URI))
        return view(request, token_parsed, *args, **kwargs)

    return __check_auth_sso