from django.urls import path
from . import views
from .views import login_sso

urlpatterns = [
    path('login-sso', login_sso, name="login_sso"),

]