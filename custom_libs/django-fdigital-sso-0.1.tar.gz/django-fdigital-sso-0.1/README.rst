=====
SSO
=====

Projeto SSO Fortaleza Digital

Quick start
-----------

1. Add "sso" to your INSTALLED_APPS setting like this::

    INSTALLED_APPS = [
        ...
        'sso',
    ]

2. Include the polls URLconf in your project urls.py like this::

    path('sso/', include('sso.urls')),

